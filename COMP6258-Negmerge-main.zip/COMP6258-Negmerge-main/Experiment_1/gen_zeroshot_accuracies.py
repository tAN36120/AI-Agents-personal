import json
import os
import torch
from src.args import parse_arguments
from src.eval import eval_single_dataset

args = parse_arguments()
args.save = os.path.join(args.results_db, args.finetuning_mode, args.model)

# Find any zeroshot.pt from the 30 standard checkpoint dirs
standard_dir = os.path.join(args.results_db, args.finetuning_mode, args.model)
zeroshot_path = None

for dir_name in sorted(os.listdir(standard_dir)):
    dir_path = os.path.join(standard_dir, dir_name)
    if not (os.path.isdir(dir_path) and "checkpoints" in dir_name):
        continue
    for dataset_dir in os.listdir(dir_path):
        candidate = os.path.join(dir_path, dataset_dir, "zeroshot.pt")
        if os.path.exists(candidate):
            zeroshot_path = candidate
            break
    if zeroshot_path:
        break

if zeroshot_path is None:
    raise FileNotFoundError("No zeroshot.pt found under standard checkpoints.")

print(f"Using pretrained checkpoint: {zeroshot_path}")
image_encoder = torch.load(zeroshot_path, map_location="cpu")

accuracies = {}
for split in ["ImageNetVal", "ImageNet"]:
    print(f"Evaluating on {split}")
    accuracies[split] = eval_single_dataset(image_encoder, split, args)["top1"]

save_path = os.path.join(args.results_db, args.finetuning_mode, args.model, "zeroshot_accuracies.json")
os.makedirs(os.path.dirname(save_path), exist_ok=True)
with open(save_path, "w") as f:
    json.dump(accuracies, f, indent=4)

print(f"Saved to {save_path}")