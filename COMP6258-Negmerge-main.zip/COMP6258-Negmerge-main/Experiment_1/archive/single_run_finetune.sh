python src/finetune.py \
  --model ViT-B-32 \
  --data-location ~/data \
  --results-db ./results \
  --cache-dir ./features_cache \
  --openclip-cachedir ~/openclip-cachedir/open_clip \
  --finetuning-mode standard \
  --auto-aug rand-m1-n1-mstd0.5 \
  --wd 0.1 \
  --seed 42