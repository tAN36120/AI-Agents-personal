#!/bin/bash
for n in 1 2 3; do
    for m in 1 2 3 4 5 6 7 8 9 10; do
        python src/eval_task_negation.py \
            --model ViT-B-32 \
            --finetuning-mode standard \
            --auto-aug "rand-m${m}-n${n}-mstd0.5" \
            --results-db /iridisfs/home/kjl1a21/COMP6258-Negmerge/Experiment_1/results \
            --seed 42
    done
done