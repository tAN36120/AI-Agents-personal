for n in 1 2 3; do
  for m in $(seq 1 10); do
    echo "=============================="
    echo "Running: Cars m=${m}, n=${n}"
    echo "=============================="
    python src/finetune.py \
      --model ViT-B-32 \
      --data-location ~/data \
      --results-db ./results \
      --cache-dir ./features_cache \
      --openclip-cachedir ~/openclip-cachedir/open_clip \
      --finetuning-mode standard \
      --auto-aug rand-m${m}-n${n}-mstd0.5 \
      --wd 0.1 \
      --seed 42
  done
done