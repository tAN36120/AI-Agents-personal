import json
import os

results_base = "/iridisfs/home/kjl1a21/COMP6258-Negmerge/Experiment_1/results/standard/ViT-B-32"

# Collect results from all 30 checkpoint dirs
cars_results = []
svhn_results = []

for dir_name in sorted(os.listdir(results_base)):
    dir_path = os.path.join(results_base, dir_name)
    if not (os.path.isdir(dir_path) and "checkpoints" in dir_name):
        continue

    json_path = os.path.join(dir_path, "negations.json")
    if not os.path.exists(json_path):
        print(f"Missing: {json_path}")
        continue

    with open(json_path) as f:
        data = json.load(f)

    aug = dir_name.replace("checkpoints_", "").replace("_42", "")

    if "Cars" in data:
        cars_results.append({
            "model": aug,
            "forget_acc": data["Cars"]["test"],
            "retain_acc": data["Cars"]["test_control"],
        })

    if "SVHN" in data:
        svhn_results.append({
            "model": aug,
            "forget_acc": data["SVHN"]["test"],
            "retain_acc": data["SVHN"]["test_control"],
        })

# Sort by forget_acc ascending (lowest forget = best negation)
cars_results.sort(key=lambda x: x["forget_acc"])
svhn_results.sort(key=lambda x: x["forget_acc"])

print("=" * 60)
print("CARS — All models ranked by forget accuracy (lowest = best)")
print("=" * 60)
for r in cars_results:
    print(f"  {r['model']:<35} forget={r['forget_acc']:.4f}  retain={r['retain_acc']:.4f}")

print()
print("=" * 60)
print("SVHN — All models ranked by forget accuracy (lowest = best)")
print("=" * 60)
for r in svhn_results:
    print(f"  {r['model']:<35} forget={r['forget_acc']:.4f}  retain={r['retain_acc']:.4f}")

print()
print("=" * 60)
print("SINGLE BEST")
print("=" * 60)
best_cars = cars_results[0]
best_svhn = svhn_results[0]
print(f"  Cars: {best_cars['model']}")
print(f"        forget={best_cars['forget_acc']:.4f}  retain={best_cars['retain_acc']:.4f}")
print(f"  SVHN: {best_svhn['model']}")
print(f"        forget={best_svhn['forget_acc']:.4f}  retain={best_svhn['retain_acc']:.4f}")